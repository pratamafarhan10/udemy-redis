import type { Session } from '$services/types';

export const getSession = async (id: string) => {};

export const saveSession = async (session: Session) => {};
